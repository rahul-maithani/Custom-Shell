📦 GUI Based Shell – Python Project 

🖥️ How to Run:
1. Unzip this folder
2. Double-click "output.exe"

✅ No installation required.
🛡️ If Windows Defender prompts:
   - Click "More info"
   - Then click "Run anyway"

📬 Feedback welcome!
